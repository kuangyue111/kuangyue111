/*
 * Safety_ADC.h
 *
 *  Created on: Sep 2, 2019
 *      Author: B33124
 */

#ifndef SAFETYLIB_SAFETY_ADC_H_
#define SAFETYLIB_SAFETY_ADC_H_

void ADC_PorSelfTest(void);

#endif /* SAFETYLIB_SAFETY_ADC_H_ */
